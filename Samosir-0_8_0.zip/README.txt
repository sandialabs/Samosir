==== LICENSING

See Samosir_license.txt for the license to Samosir.

If you are confused right now, you are probably looking for Toba.
Check out www.sf.net/toba or www.smalldataproblem.org